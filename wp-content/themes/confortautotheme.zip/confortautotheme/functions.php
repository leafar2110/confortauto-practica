<?php

function wordpress_resources(){
	
}

//get the most near ancestor of the page

@ini_set( 'upload_max_size' , '64M' );

function get_top_ancestor_id(){
	
	global $post;
	
	if($post->post_parent){
		$ancestors = array_reverse(get_post_ancestors($post->ID));
		return $ancestors[0];
	}
	
	return $post->ID;
}

//customize excerpt

function custom_excerpt_length(){
	return 25;
}

function customexcerpt($limit) {
	$excerpt = explode(' ', get_the_excerpt(), $limit);

	if (count($excerpt) >= $limit) {
		array_pop($excerpt);
		$excerpt = implode(" ", $excerpt) . '...';
	} else {
		$excerpt = implode(" ", $excerpt);
	}

	$excerpt = preg_replace('`\[[^\]]*\]`', '', $excerpt);

	return $excerpt;
}

//customize comment form

function my_custom_comment_fields( $fields ){
	if(isset($fields['url']))
	  unset($fields['url']);
	return $fields;
  }
  
  add_filter( 'comment_form_default_fields', 'my_custom_comment_fields' );

//has children for page

function has_children(){
	
	global $post;
	
	$pages = get_pages('child_of='.$post->ID);
	return count($pages);
}

//permalinks config

function reset_permalinks() {
    global $wp_rewrite;
    $wp_rewrite->set_permalink_structure( '/%category%/%postname%' );
}

add_action( 'init', 'reset_permalinks' );

//widgets

function WidgetInit(){
	
	register_sidebar( array(
		'name' => 'Barra lateral blog',
		'id' => 'sidebar1'
	));
	
	register_sidebar( array(
		'name' => 'Footer 1',
		'id' => 'footer1'
	));
}

add_action('widgets_init', 'WidgetInit');

//general setup



function wordpress_theme_setup(){
	
	register_nav_menus( array(
		'primary' => __( 'Primary Menu' ),
		'footer' => __( 'Footer Menu' ),
	));
		
	add_theme_support("post-thumbnails");
	
	add_image_size("very-small-thumbnail",90,60,array('left','top'));
	add_image_size("small-thumbnail",180,120,true);
	add_image_size("square-thumbnail", 500, 500, true);
	add_image_size("mid-thumbnail",360,240,true);
	add_image_size("large-thumbnail",720,480,true);
	add_image_size("banner-img",900, 400,array('left','top'));
	add_image_size("banner-image",920,620,array('left','top'));
	add_theme_support( 'custom-header' );
}

add_action('after_setup_theme', 'wordpress_theme_setup');

add_filter('excerpt_length', 'custom_excerpt_length');

add_action('wp_enqueue_scripts', 'wordpress_resources');

//customize option

function theme_customize_register($wp_customize){
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////HEADER
	
	
		$wp_customize->add_panel('panel1',
        array(
            'title' => 'Personalizar header',
            'priority' => 1,
            )
        );
		
		//////////////////////////////////////////////////////video
	
		$wp_customize->add_section('header', array (
		'title' => 'Video',
        'panel' => 'panel1'
		));
		
		$wp_customize->add_setting('header_media');
		
		$wp_customize->add_control( 
	new WP_Customize_Upload_Control($wp_customize, 'your_setting_id', array(
		'label'      => 'Video de fondo',
		'section'    => 'header',
		'settings'   => 'header_media',
	) ) 
);

}

add_action('customize_register','theme_customize_register');


function theme_customize_css(){ ?>
	
	
<?php	
}

add_action('wp_head', 'theme_customize_css');
?>